module fixture;
fn main() -> Int64 { return 1 }
