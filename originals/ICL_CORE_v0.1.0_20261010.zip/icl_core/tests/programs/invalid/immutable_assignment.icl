module fixture;
fn main() -> Int64 { let x = 1; x = 2; return x; }
