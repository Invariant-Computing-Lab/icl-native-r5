module fixture;
fn main() -> Int64 { let a = represent(2, "left", "world", "m"); let b = represent(5, "left", "camera", "m"); return repr_value(repr_add(a, b)); }
