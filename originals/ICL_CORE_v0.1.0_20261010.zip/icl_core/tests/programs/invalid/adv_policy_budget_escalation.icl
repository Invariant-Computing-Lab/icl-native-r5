module fixture;
fn main() -> Int64 { return 0; }
